#!/usr/bin/python3

def shrink(string=None):
	if string is None:
		print("none")
	else:
		print(string[:8])

def enlarge(string=None):
	if string is None:
		print("none")
	else:
		while len(string) != 8:
			string = string + "Z"
		print(string)

shrink("Test the shrink function.")
enlarge()
enlarge("test")
