print("42")
